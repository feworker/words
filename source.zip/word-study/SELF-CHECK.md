# genius-design 自检记录

检查页面：`http://127.0.0.1:5173/`。唯一首页：`src/pages/HomePage.tsx`。采用中文界面；英文学习材料、音标、词性、CEFR 代码、Microsoft 声音名称和 CSV/JSON 字段属于有意保留的学习内容或标准标识。

| 项目 | 结果 | 证据 |
| --- | --- | --- |
| 1. 密度、圆角、间距、点击范围 | 通过 | Button 使用 h-9 / h-8，圆角来自 6px token；实际桌面所有可见按钮尺寸均不小于 32×32。手机弹窗按钮均为 44px 高，关闭按钮为 44×44。只有状态点使用 rounded-full。单词列表为双行内容，64px 行高承载词义。 |
| 2. Token | 通过 | 对页面、导入组件、hooks 执行颜色/圆角/阴影扫描，没有硬编码颜色或任意颜色类。色值仅位于 globals.css 的 :root / .dark；Tailwind shadow DEFAULT/xs/sm/md/lg 映射共享 shadow token。打印视图按打印规范使用白底黑字。 |
| 3. 深浅主题层次 | 通过（视觉） | 实际页面切换并查看完整深色布局。深色 page/chrome/card 亮度为 0.0073/0.0115/0.0169，逐层变亮。见 dark-preview.png 与 contrast-audit.json。 |
| 4. Primitive 边界 | 通过 | 9 个按需安装的 shadcn 源组件全部位于 components/ui。Button/Badge 保留 CVA，Input/Select/Dialog/Progress/Textarea 保留 cn、ref 和 displayName。页面/ImportDialog 不引入 focus-within、:has 或共享外部焦点壳；直接使用已有 primitives。 |
| 5. 响应式 | 通过（视觉） | 1280/1024/768/390px 实際页面截图与 DOM 检查，document.scrollWidth 均等于 viewport width。导航在 1280px 以下缩为图标，辅助栏在 1024px 以下隐藏，手机词库进入弹窗。固定 220px 词表与 208px 辅助栏属于固定面板例外。 |
| 6. 图标 | 通过 | 页面及导入组件仅使用按名称导入的 lucide-react；图标按钮均有 t() aria-label，旁边有文字的图标使用 aria-hidden。 |
| 7. 交互状态 | 通过（视觉） | 默认与点击/悬停颜色、键盘焦点可见；第一页上一词 disabled；空导入两按钮 disabled；动态 TTS loading 按钮 disabled + skeleton；音频失败显示重试；均在实际首页查看。相同 primitive 的状态由组件统一提供。 |
| 8. i18n | 通过 | 页面、ImportDialog、Dialog 关闭文案均通过 src/lib/i18n.ts；中文 chrome 无未翻译导航。学习英文内容为明确例外。数值使用 Intl.NumberFormat，日期使用 Intl.DateTimeFormat。当前仅支持中文，中文基数无单复数形式。 |
| 9. 键盘与焦点 | 通过（视觉） | Tab 后按钮呈 1px ring；设置弹窗连续 8 次 Tab，activeElement 始终位于 dialog 内；Escape 关闭并返回设置触发按钮。导入弹窗同样验证返回触发按钮。手机版打开词库时检查重复 ID，已为桌面/手机搜索使用不同 ID。 |
| 10. 对比度 | 通过 | 从实际页面 CSS token 计算 WCAG AA 对比度：浅色最小 5.00:1，深色最小 4.86:1（11 组文字/背景配对）；完整结果见 contrast-audit.json。 |
| 11. 常见模式 | 通过 | shadcn Input/Textarea/Select/Dialog/Alert/Skeleton/Progress；搜索防抖 250ms + 清除；导入行内校验和预览；音频持续错误提供可见重试；暂态导入成功提示 4.5 秒。 |
| 12. 减少动效 | 通过 | globals.css 使用 prefers-reduced-motion: reduce 关闭 animation/transition；另有可见的“减少动效”开关。实际设置开启后 transitionDuration=0s、animationName=none。浏览器系统偏好未在工具层单独模拟，两个 off-path 共享关闭声明。 |
| 13. 无 emoji | 通过 | 静态扫描 src/**/*.tsx、i18n 与词库内容无 U+1F300–1FAFF、U+2600–27BF、区域旗帜等 emoji。UI 图标为 lucide。 |
| 14. 类型与构建 | 通过 | npm test：9 个导入校验用例通过；npm run typecheck：0 错误；npm run build：成功。 |
| 15. 入口一致性 | 通过 | index.html 的 /src/main.tsx 只加载 App，App 只渲染 HomePage。最小首页在原位置替换，没有并行预览页面。 |
| 16. 实际视觉验收 | 通过（视觉） | 同一实际 URL 查看默认、深色、焦点、disabled、loading、导入及设置 overlays、音频错误。遮罩最初因开发缓存未刷新而无颜色，重启后实际背景变为 rgba(17,20,29,0.5)，已修复并重新检查。无重复外边框或焦点圈。 |

## 功能证据

- Microsoft Jenny 单词 MP3 实际在 audio 元素中播放，时长 1.872 秒，paused=false；例句 MP3 时长 5.208 秒，暂停可用。
- 新导入 consistent 的配套例句通过本地 /api/tts 返回音频，浏览器 Blob MP3 时长 3.456 秒，没有 media error。
- Ryan 英式声音 API 返回 24kHz、48kbps、单声道 MP3。
- 预置 12 个单词和 18 条例句，共 30 个可播放 Microsoft MP3。
- JSON 粘贴预览 → 导入 → 单词、释义、讲解、例句联动；真实 CSV 文件选择 → file.text → 格式预览通过。
- 缺少 meaning、重复单词、错误 JSON、破损 CSV、2,001 词等输入被拒绝，共 9 个校验测试。
- 收藏、掌握和笔记通过刷新验证保留；浏览器保留了“验证词库”作为导入演示记录。
- 故意配置不可用音频地址，查看失败提示及重试路径；最终通过刷新恢复默认本地服务与 Jenny。
- npm start 从无项目内 .venv 的状态建立环境并同时启动两个服务。

## 使用边界

默认 Edge 在线 TTS 路径经过实测；Azure Speech 可选路径未使用真实 Azure 凭据调用。新内容需要联网；查询在线词典补全，缺失资料明确提示，不编造释义或例句。当前只提供中文界面，本地数据不跨设备同步。打印 CSS 提供学习卡样式；本次没有导出打印 PDF。


## 本次增量：联网查词自动入库

检查日期：2026-10-26。检查 URL 与唯一首页保持一致，下面仅记录本次改动的 16 项复核。

| 项目 | 结果 | 本轮证据 |
| --- | --- | --- |
| 1. 密度与点击范围 | 通过；修复手机来源链接 | 查词 Button size=sm，高 32px；手机弹窗中所有按钮/输入均 ≥44×44；来源链接手机实测 192×44。普通动作无 pill，rounded-full 唯一命中仍为状态点。 |
| 2. Tokens | 通过 | rg 扫描 HomePage.tsx / useWordLookup.ts 无 hex、任意颜色、圆角或阴影值；沿用现有 Button/Alert/Skeleton token。 |
| 3. 深浅层次 | 通过（视觉） | 同一页面切换主题检查查词栏、词卡和来源链接，见更新后的 dark-preview.png；沿用原对比度及层次 token。 |
| 4. shadcn 边界 | 通过 | 新增入口直接复用 Input、Button、Alert、Skeleton，无共享焦点壳、focus-within、:has、neutralising utilities；组件仍为原 9 个 shadcn 源组件。 |
| 5. 响应式 | 通过（视觉） | 1280/1024/768/390px 实际截图检查，DOM scrollWidth=viewport width；手机“打开词库”内可查词，成功自动显示词卡。 |
| 6. 图标 | 通过 | 查词 Search、等待 Clock3、错误 AlertCircle 沿用 lucide 按名称导入，旁边有标签且 aria-hidden。 |
| 7. 默认/焦点/禁用/加载 | 通过（视觉） | 空框按钮 disabled；qzxqzxqzx 加载 skeleton + 禁用按钮；缩短等待文案避免 220px 栏内省略；Enter 和按钮提交均实测。 |
| 8. i18n | 通过 | 新文案统一 t()，字母排序的 i18n key；英文词典学习材料及来源名称是允许的第三方内容。缺项提示已更新为联网补全指引。 |
| 9. 键盘与焦点 | 通过（视觉） | 输入框 Enter 查词；Input→Tab 聚焦查词按钮，深色计算样式为 1px ring（rgb(130,132,243)）；按钮 Enter 定位已有词。词库弹窗 Escape 关闭，手机查词成功返回打开词库触发按钮。错误通过 aria-invalid/aria-describedby 关联输入。 |
| 10. 对比度 | 通过 | 新控件没有新 token 或配色；复用 contrast-audit.json 内正文、primary、muted、destructive 对比度证据（浅色最低 5.00:1，深色最低 4.86:1），实际深浅页面可读。 |
| 11. 常见模式 | 通过 | 本地筛选保持 250ms 防抖；联网查询明确提交，loading 用 Skeleton、持久错误用 Alert、成功提示 4.5s；错误后可编辑拼写并再次提交。 |
| 12. 减少动效 | 通过 | 新 Skeleton 使用现有 animate-pulse；globals.css 的 prefers-reduced-motion 及 data-motion=reduce 都关闭 animation/transition，与之前实际设置 off-path 共用声明；无新增独立动效。 |
| 13. 无 emoji | 通过 | 本轮 src 页面/hook/i18n 静态扫描无 emoji；UI 仅使用 lucide。 |
| 14. 类型与构建 | 通过 | npm test：9 个导入用例；Python unittest：8 个词典解析/校验/故障用例；npm run build 内含 tsc --noEmit，成功。 |
| 15. 入口一致 | 通过 | 仍为 index.html→main.tsx→App.tsx→HomePage.tsx，查词 hook 和 Python 路由被实际首页调用。 |
| 16. 视觉验收 | 通过（视觉） | 同一实际 URL 观察 default、keyboard focus、disabled、loading、拼写无结果、中文非法输入、手机词库 overlay；搜索和按钮各自仅一层边框/焦点，见 preview.png / dark-preview.png / mobile-preview.png。 |

### 本轮功能结果

- abundant 从浏览器 Enter 查询，自动创建查词生词本，得到 /əˈbʌndənt/、adj.、中文释义、讲解、2 个搭配、3 条双语例句及有道来源。
- 再次提交 abundant 只定位，计数不增加；刷新后词库管理中仍有条目。
- 新词 abundant 的微软 Jenny Blob MP3 实测时长 1.872s；新例句 MP3 时长 3.048s，无 media error；本地服务 POST /api/tts 均返回 200。
- 只包含 vivid 与“生动的”的 JSON 导入后，查询补齐音标、词性、讲解、3 个搭配及3条双语例句，词数仍为1，原释义保留。
- 手机查询 lucid 成功后自动关闭词库弹窗，显示已保存的完整词卡及来源。
- qzxqzxqzx 返回 not_found；中文提交显示英文输入要求，均未新增词条。
- meticulous 提交后立刻改为 abundant，加载结束且旧结果未入库；后续词库计数及列表确认。eloquent 的先前请求在修改前已完成，因此保留为有效演示词。
- 8 个离线 Python 用例覆盖所有释义、HTML 清理、双语要求、例句去重、缺项提示、无条目、输入校验不访问网络、网络故障映射。

接受的例外：无新增例外。词典覆盖有限时保存已有资料并列明缺项；Azure TTS 路径依旧未实测。


## Pages 部署增量复核

目标 https://feworker.github.io/words/ ，生产构建验收 http://127.0.0.1:8870/words/ 。

| 项目 | 结果与证据 |
| --- | --- |
| 1 密度与点击范围 | 通过；沿用原 Input/Button/Alert，不新增普通控件形状。 |
| 2 Tokens | 通过；改动页面/hooks/service 静态 rg 无硬编码颜色、任意圆角或阴影。 |
| 3 深浅主题 | 通过；配色与原 theme token 一致，生产页沿用相同样式；之前主题视觉验收证据仍适用。 |
| 4 shadcn 边界 | 通过；服务地址仍使用现有 Input/Dialog/Button，未新增跨子元素样式壳。 |
| 5 响应式 | 通过；布局未更改，原 1280/1024/768/390 证据仍适用；线上服务帮助文字允许换行。 |
| 6 图标 | 通过；未新增图标源或图标含义。 |
| 7 状态 | 通过（视觉）；生产页空查词按钮 disabled；查询缺省后端显示配置提示；服务地址错误内联显示。 |
| 8 i18n | 通过；新增服务提示均通过 t()，键排序，中文 UI；第三方名称、学习材料为原例外。 |
| 9 键盘 | 通过（视觉）；Enter 查询配置提示；设置提交校验失败仍留在弹窗；保存空配置关闭并返回触发按钮。 |
| 10 对比度 | 通过；原 token 配对不变，继续引用 contrast-audit.json。 |
| 11 常见模式 | 通过；复用 Input/Dialog/Alert；生产环境未配置 API 不向静态 Pages 发送无效 POST。 |
| 12 减少动效 | 通过；未新增动画，原 CSS off-path 保持。 |
| 13 无 emoji | 通过；新增文字无 emoji，仅保留 lucide。 |
| 14 类型/构建 | 通过；npm test 9 用例；build:pages 包含 tsc --noEmit 和 /words/ Vite 构建；30 个 manifest 文件均存在。经典公开配置脚本由 HTML 单独加载，Vite 不打包提示是预期行为。 |
| 15 入口一致 | 通过；仍使用原 HomePage，发布入口 JS/CSS/config 统一以 /words/ 为基路径。 |
| 16 实际视觉 | 通过（视觉）；生产构建首页、音频播放、配置缺省提示、设置弹窗及错误校验均在 /words/ 检查，无重复边框/焦点。 |

功能证据：生产构建预置 serendipity 直接从 /words/449e7cb9ffe45ea56ecc.mp3 播放，1.872s，paused=false；abundant 查询明确提示未配置联网服务，不写入无效条目。HTTP 服务地址在生产版被拒绝；空配置可保存。服务地址用于查词及 TTS，存于当前浏览器。Edge WebSocket 普通网页直连实测连接错误/1006，无音频，未声称可用。

本次未部署公网 Python 服务，联网补全与非预置微软音频等待配置；公开配置不含密钥。Pages 发布仓库使用 feworker 浏览器账号，源码保存在 source.zip；提交作者为 feworker。


公网发布结果：GitHub Pages run 40282217826（commit 2320905defa48360fe532cf16a263040541cd9cc）构建与部署全部成功，2026-10-26。HTTP /words 自动跳转 HTTPS /words/。实际公网页面 https://feworker.github.io/words/ 可见，预置单词 MP3 时长 1.872s，paused=false，实际 src 为 https://feworker.github.io/words/449e7cb9ffe45ea56ecc.mp3；例句音频也可播放。线上截图见 ../words-live.png。

补充用户指定方案验证：只用公开 TrustedClientToken，en-US-AriaNeural，audio-24khz-48kbitrate-mono-mp3，普通浏览器 WebSocket 未收到音频，关闭 1006。带 https://feworker.github.io Origin 的协议测试，无附加参数及当前 edge-tts 附加参数两种请求均返回握手 HTTP 403。没有声称所有浏览器或未来接口均不可用；当前发布版本继续使用真实预置音频与可配置后端。


## 标签页 icon 增量自检（genius-design §5a）

本轮只修改文档 head、标题同步及生成脚本，不改页面控件、布局或样式。

| 项目 | 结果与证据 |
| --- | --- |
| 1 密度/圆角/间距 | 通过（静态）；无控件及布局变更，favicon 内部 24×24 为 lucide 标准视框。 |
| 2 Tokens | 通过；SVG 的 --primary 自动读取 globals.css，stroke=currentColor，无 hex 色值。 |
| 3 深浅主题 | 通过；图标内 media prefers-color-scheme:dark 切换现有深色 primary，页面主题层次不变。 |
| 4 Primitive 边界 | 通过；没有新增/改动 primitives 或 feature 样式壳。 |
| 5 响应式 | 通过（静态）；页面布局没有差异，原响应式证据继续适用。 |
| 6 图标/标签身份 | 修复后通过；从已安装 lucide-react BookOpen 导出 SVG，两条 path 与现有书本概念一致；Chrome 实际标签栏已显示蓝紫色书本，截图 ../words-tab.png。深色媒体规则已检查；不更改系统主题。 |
| 7 控件状态 | 通过（静态）；没有新增控件，页面原默认/禁用/焦点/弹窗状态保持。 |
| 8 i18n | 通过；browserTitle 通过 t()，keys 按字母排序；html lang 来自 locale=zh-CN。 |
| 9 键盘/焦点 | 通过（静态）；没有修改键盘或焦点逻辑；标题同步 effect 不移动焦点。 |
| 10 对比度 | 通过；复用已有 primary token 对比度，浅色对 card 7.55:1，深色对 card 4.86:1；Chrome 浅色标签栏图标清晰，深色切换采用更亮 token。 |
| 11 常见模式 | 通过（静态）；新增为文档 head 和 effect，不增加交互模式。 |
| 12 减少动效 | 通过（静态）；favicon/标题没有动画。 |
| 13 无 emoji | 通过；lucide 图形，无 emoji。 |
| 14 类型/构建 | 通过；build:pages 含 tsc --noEmit，Vite 成功，生成 favicon.svg。 |
| 15 入口一致 | 通过；唯一首页不变；HTML icon href 使用 BASE_URL，本地 DOM 实测 /favicon.svg，构建为 /words/favicon.svg。 |
| 16 视觉验收 | 通过（视觉）；Chrome 本地实际页面与标签栏检查，无页面视觉回归。页面切换职场表达后 document.title 更新为“职场表达 · 英语单词学习 · 词间”，lang=zh-CN。 |

接受例外：无。没有宣称已切换 OS 深色标签栏，深色适配以 SVG 内声明的媒体规则与现有 token 为证据。
