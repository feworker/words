import { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BookOpen,
  Bookmark,
  Check,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Download,
  Headphones,
  Layers3,
  Menu,
  Moon,
  Pause,
  Play,
  Repeat2,
  Search,
  Settings2,
  Sun,
  Target,
  Volume2,
  X,
  ChartNoAxesColumnIncreasing,
  Lightbulb,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import ImportDialog from "@/components/ImportDialog";
import { t, type CopyKey } from "@/lib/i18n";
import { samples, type Collection, type Word } from "@/lib/words";
import { download } from "@/lib/import";
import { useAudio } from "@/hooks/useAudio";
import { useWordLookup } from "@/hooks/useWordLookup";
import { loadService, validService } from "@/lib/service";

type Saved = {
  collections: Collection[];
  known: string[];
  stars: string[];
  notes: Record<string, string>;
  daily: { date: string; ids: string[] };
};
const today = () => new Intl.DateTimeFormat("en-CA").format(new Date());
const initial: Saved = {
  collections: [],
  known: [],
  stars: [],
  notes: {},
  daily: { date: today(), ids: [] },
};
function load(): Saved {
  try {
    const s = JSON.parse(localStorage.getItem("word-study-v1") || "null");
    if (
      !s ||
      !Array.isArray(s.collections) ||
      !Array.isArray(s.known) ||
      !Array.isArray(s.stars) ||
      !s.notes ||
      typeof s.notes !== "object" ||
      !s.daily ||
      !Array.isArray(s.daily.ids)
    )
      return initial;
    return {
      ...s,
      collections: s.collections.filter(
        (c: Collection) =>
          c &&
          typeof c.id === "string" &&
          typeof c.name === "string" &&
          Array.isArray(c.words) &&
          c.words.every(
            (w: Word) =>
              w &&
              typeof w.word === "string" &&
              typeof w.meaning === "string" &&
              Array.isArray(w.examples),
          ),
      ),
      daily: s.daily.date === today() ? s.daily : initial.daily,
    };
  } catch {
    return initial;
  }
}
const fmt = (n: number) => new Intl.NumberFormat("zh-CN").format(n);
const stamp = (n: number) =>
  `${Math.floor(n / 60)}:${String(Math.floor(n % 60)).padStart(2, "0")}`;
export default function HomePage() {
  const [reducedMotion, setReducedMotion] = useState(false);
  useEffect(() => {
    document.documentElement.dataset.motion = reducedMotion
      ? "reduce"
      : "normal";
  }, [reducedMotion]);
  const [saved, setSaved] = useState<Saved>(load),
    [collection, setCollection] = useState("daily"),
    [id, setId] = useState(samples[0].id),
    [search, setSearch] = useState(""),
    [query, setQuery] = useState(""),
    [filter, setFilter] = useState("all"),
    [storageError, setStorageError] = useState(false),
    [notice, setNotice] = useState(""),
    [dark, setDark] = useState(() => {
      try {
        return localStorage.getItem("word-study-theme") === "dark";
      } catch {
        return false;
      }
    }),
    [voice, setVoice] = useState("en-US-JennyNeural"),
    [rate, setRate] = useState("1"),
    [endpoint, setEndpoint] = useState(loadService),
    [endpointDraft, setEndpointDraft] = useState(""),
    [endpointError, setEndpointError] = useState(false),
    [settingsOpen, setSettingsOpen] = useState(false),
    [mobileOpen, setMobileOpen] = useState(false);
  const audio = useAudio(voice, Number(rate), endpoint),
    goal = 12;
  const lookup = useWordLookup(endpoint);
  const savedRef = useRef(saved);
  savedRef.current = saved;
  const collections: Collection[] = useMemo(
    () => [
      { id: "daily", name: t("daily"), words: samples },
      {
        id: "business",
        name: t("business"),
        words: samples.filter((w) => w.category === "business"),
      },
      {
        id: "life",
        name: t("life"),
        words: samples.filter((w) => w.category === "life"),
      },
      ...saved.collections,
    ],
    [saved.collections],
  );
  const currentCollection =
    collections.find((c) => c.id === collection) || collections[0];
  const words = (
    collection === "stars"
      ? collections
          .filter((c) => !["business", "life"].includes(c.id))
          .flatMap((c) => c.words)
          .filter((w) => saved.stars.includes(w.id))
      : currentCollection.words
  ).filter(
    (w) =>
      (!query ||
        `${w.word} ${w.meaning}`.toLowerCase().includes(query.toLowerCase())) &&
      (filter === "all" ||
        (filter === "known"
          ? saved.known.includes(w.id)
          : !saved.known.includes(w.id))),
  );
  const word = words.find((w) => w.id === id) || words[0],
    index = word ? words.findIndex((w) => w.id === word.id) : 0,
    knownCount = currentCollection.words.filter((w) =>
      saved.known.includes(w.id),
    ).length,
    dailyCount = saved.daily.date === today() ? saved.daily.ids.length : 0,
    mastered = word && saved.known.includes(word.id),
    starred = word && saved.stars.includes(word.id);
  const totalWords =
      samples.length +
      saved.collections.reduce((n, c) => n + c.words.length, 0),
    libraryTitle =
      collection === "stars" ? t("favorite") : currentCollection.name;
  const playRef = useRef(audio.stop);
  playRef.current = audio.stop;
  useEffect(() => {
    const timer = setTimeout(() => setQuery(search.trim()), 250);
    return () => clearTimeout(timer);
  }, [search]);
  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
    try {
      localStorage.setItem("word-study-theme", dark ? "dark" : "light");
    } catch {}
  }, [dark]);
  useEffect(() => {
    playRef.current();
  }, [word?.id]);
  useEffect(() => {
    if (!notice) return;
    const timer = setTimeout(() => setNotice(""), 4500);
    return () => clearTimeout(timer);
  }, [notice]);
  function persist(next: Saved) {
    savedRef.current = next;
    setSaved(next);
    try {
      localStorage.setItem("word-study-v1", JSON.stringify(next));
      setStorageError(false);
    } catch {
      setStorageError(true);
    }
  }
  function switchCollection(value: string) {
    lookup.cancel();
    setCollection(value);
    setSearch("");
    setQuery("");
    setFilter("all");
    audio.stop();
    setMobileOpen(false);
  }
  function navigate(direction: number) {
    if (words[index + direction]) setId(words[index + direction].id);
  }
  function mark() {
    if (!word) return;
    const daily =
      saved.daily.date === today() ? saved.daily : { date: today(), ids: [] };
    persist({
      ...saved,
      known: mastered
        ? saved.known.filter((x) => x !== word.id)
        : [...saved.known, word.id],
      daily: {
        ...daily,
        ids: mastered
          ? daily.ids.filter((x) => x !== word.id)
          : Array.from(new Set([...daily.ids, word.id])),
      },
    });
  }
  function favorite() {
    if (word)
      persist({
        ...saved,
        stars: starred
          ? saved.stars.filter((x) => x !== word.id)
          : [...saved.stars, word.id],
      });
  }
  function imported(c: Collection) {
    persist({ ...saved, collections: [...saved.collections, c] });
    switchCollection(c.id);
    setId(c.words[0].id);
    setNotice(t("importSuccess", { count: c.words.length }));
  }
  function submitLookup() {
    const target = search.trim().toLowerCase();
    const groups = [
      { id: "daily", name: t("daily"), words: samples },
      ...savedRef.current.collections,
    ];
    const matchGroup = groups.find((c) =>
      c.words.some((w) => w.word.toLowerCase() === target),
    );
    const match = matchGroup?.words.find(
      (w) => w.word.toLowerCase() === target,
    );
    if (
      match &&
      match.phonetic &&
      match.pos &&
      match.explanation &&
      match.phrases.length &&
      match.examples.some((e) => e.text && e.translation)
    ) {
      switchCollection(matchGroup!.id);
      setId(match.id);
      setNotice(t("lookupExisting", { word: match.word }));
      return;
    }
    void lookup.run(target, (result) => {
      const latest = savedRef.current;
      const existing = latest.collections.find((c) =>
        c.words.some((w) => w.word.toLowerCase() === target),
      );
      const existingWord = existing?.words.find(
        (w) => w.word.toLowerCase() === target,
      );
      const destination = existing?.id || "lookup";
      const enriched = existingWord
        ? {
            ...existingWord,
            phonetic: existingWord.phonetic || result.phonetic,
            pos: existingWord.pos || result.pos,
            meaning: existingWord.meaning || result.meaning,
            explanation: existingWord.explanation || result.explanation,
            examples: existingWord.examples.some((e) => e.text && e.translation)
              ? existingWord.examples
              : result.examples,
            phrases: existingWord.phrases.length
              ? existingWord.phrases
              : result.phrases,
            sources: result.sources,
            missingFields: result.missingFields?.filter((field) => {
              if (field === "examples")
                return !existingWord.examples.some(
                  (e) => e.text && e.translation,
                );
              if (field === "phrases") return !existingWord.phrases.length;
              if (field === "phonetic") return !existingWord.phonetic;
              if (field === "pos") return !existingWord.pos;
              return true;
            }),
          }
        : result;
      const hasBucket = latest.collections.some((c) => c.id === destination);
      const updated = hasBucket
        ? latest.collections.map((c) =>
            c.id !== destination
              ? c
              : {
                  ...c,
                  words: existingWord
                    ? c.words.map((w) =>
                        w.id === existingWord.id ? enriched : w,
                      )
                    : [...c.words, enriched],
                },
          )
        : [
            ...latest.collections,
            { id: "lookup", name: t("lookupLibrary"), words: [enriched] },
          ];
      persist({ ...latest, collections: updated });
      setCollection(destination);
      setId(enriched.id);
      setSearch("");
      setQuery("");
      setFilter("all");
      audio.stop();
      setMobileOpen(false);
      setNotice(t("lookupAdded", { word: enriched.word }));
    });
  }
  const libraryList = (
    <div className="space-y-1">
      {collections.map((c) => (
        <Button
          key={c.id}
          variant={collection === c.id ? "secondary" : "ghost"}
          className="w-full justify-start text-xs"
          onClick={() => switchCollection(c.id)}
        >
          <BookOpen aria-hidden="true" />
          <span className="flex-1 text-start truncate">{c.name}</span>
          <span className="text-muted-foreground tabular-nums">
            {fmt(c.words.length)}
          </span>
        </Button>
      ))}
    </div>
  );
  const queuePanel = (suffix: string) => (
    <section
      className="min-w-0 border rounded-md bg-card overflow-hidden flex flex-col"
      aria-label={t("library")}
    >
      <div className="p-4 border-b">
        <div className="flex items-center justify-between gap-2 mb-3">
          <h2 className="font-semibold">{libraryTitle}</h2>
          <Badge variant="secondary" className="font-normal">
            {t("count", { count: words.length })}
          </Badge>
        </div>
        <label className="sr-only" htmlFor={`word-search-${suffix}`}>
          {t("search")}
        </label>
        <Input
          id={`word-search-${suffix}`}
          aria-invalid={!!lookup.error}
          aria-describedby={`lookup-help-${suffix}${lookup.error ? ` lookup-error-${suffix}` : ""}`}
          value={search}
          onChange={(e) => {
            lookup.cancel();
            setSearch(e.target.value);
          }}
          onKeyDown={(e) => {
            if (
              e.key === "Enter" &&
              !e.nativeEvent.isComposing &&
              search.trim() &&
              !lookup.loading
            ) {
              e.preventDefault();
              submitLookup();
            }
          }}
          placeholder={t("search")}
          className="text-xs"
        />
        <p
          id={`lookup-help-${suffix}`}
          className="mt-2 text-xs leading-5 text-muted-foreground"
        >
          {t("lookupHint")}
        </p>
        <Button
          className="mt-2 w-full"
          size="sm"
          disabled={!search.trim() || lookup.loading}
          onClick={submitLookup}
        >
          {lookup.loading ? (
            <Clock3 aria-hidden="true" />
          ) : (
            <Search aria-hidden="true" />
          )}
          {lookup.loading ? t("lookupBusy") : t("lookupAction")}
        </Button>
        {lookup.loading && (
          <div role="status" className="mt-3">
            <Skeleton className="h-3 w-full" />
            <Skeleton className="h-3 w-3/4 mt-2" />
          </div>
        )}
        {lookup.error && (
          <Alert
            id={`lookup-error-${suffix}`}
            variant="destructive"
            className="mt-3"
          >
            <AlertCircle aria-hidden="true" />
            <AlertDescription>{lookup.error}</AlertDescription>
          </Alert>
        )}
        {search && (
          <Button
            variant="link"
            size="sm"
            className="px-0 mt-1"
            onClick={() => {
              setSearch("");
              setQuery("");
              lookup.cancel();
            }}
          >
            <X aria-hidden="true" />
            {t("clear")}
          </Button>
        )}
        <div className="grid grid-cols-3 gap-1 mt-3" aria-label={t("status")}>
          {[
            ["all", "tabsAll"],
            ["new", "tabsNew"],
            ["known", "tabsKnown"],
          ].map(([value, key]) => (
            <Button
              key={value}
              size="sm"
              variant={filter === value ? "secondary" : "ghost"}
              className="px-1 text-xs"
              aria-pressed={filter === value}
              onClick={() => setFilter(value)}
            >
              {t(key as CopyKey)}
            </Button>
          ))}
        </div>
      </div>
      <div className="flex-1 overflow-y-auto max-h-[36rem]">
        {words.map((w, i) => (
          <Button
            key={w.id}
            variant={word?.id === w.id ? "secondary" : "ghost"}
            className="w-full h-auto min-h-16 justify-start rounded-sm px-4 py-3 whitespace-normal text-start border-b"
            onClick={() => {
              setId(w.id);
              setMobileOpen(false);
            }}
            aria-current={word?.id === w.id ? "true" : undefined}
          >
            <span className="text-xs text-muted-foreground tabular-nums w-4 shrink-0">
              {String(i + 1).padStart(2, "0")}
            </span>
            <span className="min-w-0 flex-1">
              <span className="block font-medium break-words">{w.word}</span>
              <span className="block text-xs font-normal text-muted-foreground truncate mt-1">
                {w.meaning}
              </span>
            </span>
            {saved.known.includes(w.id) && (
              <CheckCircle2
                className="text-success"
                aria-label={t("familiar")}
              />
            )}
          </Button>
        ))}
        {!words.length && (
          <div className="p-6 text-center text-muted-foreground">
            <Search className="mx-auto size-6 mb-3" aria-hidden="true" />
            <p className="font-medium">{t("empty")}</p>
            <p className="text-xs leading-5 mt-2">{t("emptyHelp")}</p>
          </div>
        )}
      </div>
      <div className="p-3 border-t text-xs text-muted-foreground flex items-center gap-2">
        <Headphones className="size-4" aria-hidden="true" />
        {t("guide")}
      </div>
    </section>
  );
  return (
    <div className="min-h-screen flex">
      <aside className="print-hidden hidden md:flex flex-col w-16 xl:w-48 shrink-0 border-e bg-chrome">
        <div className="h-16 flex items-center gap-3 px-4 xl:px-5 border-b">
          <div className="size-8 rounded-md bg-primary text-primary-foreground flex items-center justify-center shrink-0">
            <BookOpen className="size-5" aria-hidden="true" />
          </div>
          <span className="hidden xl:block font-semibold text-lg tracking-wide">
            {t("app")}
          </span>
        </div>
        <nav className="p-2 xl:p-3 space-y-2 mt-4" aria-label={t("study")}>
          <Button
            variant="secondary"
            className="w-full px-2 xl:px-3 justify-start"
            aria-label={t("study")}
            onClick={() => switchCollection("daily")}
          >
            <Layers3 aria-hidden="true" />
            <span className="hidden xl:block">{t("study")}</span>
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button
                variant="ghost"
                className="w-full px-2 xl:px-3 justify-start"
                aria-label={t("libraryManager")}
              >
                <BookOpen aria-hidden="true" />
                <span className="hidden xl:block">{t("libraryManager")}</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card">
              <DialogHeader>
                <DialogTitle>{t("libraryManager")}</DialogTitle>
                <DialogDescription>
                  {t("libraryManagerDescription")}
                </DialogDescription>
              </DialogHeader>
              {libraryList}
              <Button
                variant="outline"
                onClick={() =>
                  download(
                    "word-library.json",
                    JSON.stringify(currentCollection.words, null, 2),
                    "application/json",
                  )
                }
              >
                <Download aria-hidden="true" />
                {t("export")}
              </Button>
            </DialogContent>
          </Dialog>
          <Button
            variant={collection === "stars" ? "secondary" : "ghost"}
            className="w-full px-2 xl:px-3 justify-start"
            aria-label={t("bookmarks")}
            onClick={() => switchCollection("stars")}
          >
            <Bookmark aria-hidden="true" />
            <span className="hidden xl:block">{t("bookmarks")}</span>
          </Button>
          <Dialog>
            <DialogTrigger asChild>
              <Button
                variant="ghost"
                className="w-full px-2 xl:px-3 justify-start"
                aria-label={t("stats")}
              >
                <ChartNoAxesColumnIncreasing aria-hidden="true" />
                <span className="hidden xl:block">{t("stats")}</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card">
              <DialogHeader>
                <DialogTitle>{t("progress")}</DialogTitle>
                <DialogDescription>
                  {t("progressDescription")}
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-3 gap-3">
                {[
                  [t("totalWords"), totalWords],
                  [t("totalMastered"), saved.known.length],
                  [t("totalSaved"), saved.stars.length],
                ].map(([label, count]) => (
                  <div className="bg-muted p-3 rounded-md" key={label}>
                    <p className="text-xs text-muted-foreground">{label}</p>
                    <p className="text-2xl font-semibold mt-2 tabular-nums">
                      {fmt(Number(count))}
                    </p>
                  </div>
                ))}
              </div>
              <p>
                {t("progressText", {
                  done: knownCount,
                  total: currentCollection.words.length,
                })}
              </p>
              <Progress
                value={(knownCount / currentCollection.words.length) * 100}
              />
            </DialogContent>
          </Dialog>
        </nav>
        <div className="hidden xl:block px-3 mt-8">
          <p className="text-xs text-muted-foreground px-3 mb-3">
            {t("library")}
          </p>
          {libraryList}
        </div>
        <div className="mt-auto p-3 hidden xl:block">
          <div className="border rounded-md p-3 bg-card">
            <p className="font-medium text-xs flex items-center gap-2">
              <Lightbulb className="size-4 text-primary" aria-hidden="true" />
              {t("guide")}
            </p>
            <p className="text-xs text-muted-foreground leading-5 mt-2">
              {t("guideText")}
            </p>
          </div>
          <p className="text-xs text-muted-foreground mt-4 px-1">
            {t("bookLabel")}
          </p>
        </div>
      </aside>
      <div className="min-w-0 flex-1">
        <header className="print-hidden h-16 border-b bg-chrome px-4 md:px-6 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <span className="font-semibold md:hidden">{t("app")}</span>
            <span className="text-muted-foreground hidden sm:inline">
              {t("study")}
            </span>
            <ChevronRight
              className="size-3 text-muted-foreground hidden sm:block"
              aria-hidden="true"
            />
            <span className="truncate hidden sm:inline">{libraryTitle}</span>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              aria-label={dark ? t("themeLight") : t("themeDark")}
              onClick={() => setDark(!dark)}
            >
              {dark ? <Sun aria-hidden="true" /> : <Moon aria-hidden="true" />}
            </Button>
            <Dialog
              open={settingsOpen}
              onOpenChange={(v) => {
                setSettingsOpen(v);
                setEndpointDraft(endpoint);
                setEndpointError(false);
              }}
            >
              <DialogTrigger asChild>
                <Button variant="ghost" size="icon" aria-label={t("settings")}>
                  <Settings2 aria-hidden="true" />
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card">
                <DialogHeader>
                  <DialogTitle>{t("settings")}</DialogTitle>
                  <DialogDescription>
                    {t("settingsDescription")}
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <label>{t("voice")}</label>
                    <Select value={voice} onValueChange={setVoice}>
                      <SelectTrigger aria-label={t("voice")}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {[
                          ["en-US-JennyNeural", "voiceJenny"],
                          ["en-US-AriaNeural", "voiceAria"],
                          ["en-GB-RyanNeural", "voiceRyan"],
                        ].map(([v, k]) => (
                          <SelectItem key={v} value={v}>
                            {t(k as CopyKey)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="service-endpoint">{t("endpoint")}</label>
                    <Input
                      id="service-endpoint"
                      value={endpointDraft}
                      aria-invalid={endpointError}
                      aria-describedby={
                        endpointError ? "service-error" : undefined
                      }
                      onChange={(e) => {
                        setEndpointDraft(e.target.value);
                        setEndpointError(false);
                      }}
                      placeholder={t("endpoint")}
                    />
                    <p className="text-xs text-muted-foreground leading-5">
                      {t("endpointHelp")}
                    </p>
                    {endpointError && (
                      <p
                        id="service-error"
                        className="text-destructive text-xs"
                      >
                        {t("endpointInvalid")}
                      </p>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {t("voicePrivacy")}
                  </p>
                  <Button
                    variant={reducedMotion ? "secondary" : "outline"}
                    aria-pressed={reducedMotion}
                    onClick={() => setReducedMotion(!reducedMotion)}
                  >
                    {t("reducedMotion")}
                  </Button>
                  <Button
                    onClick={() => {
                      try {
                        if (!validService(endpointDraft.trim()))
                          throw new Error();
                        lookup.cancel();
                        setEndpoint(endpointDraft.trim());
                        try {
                          localStorage.setItem(
                            "word-study-service",
                            endpointDraft.trim(),
                          );
                        } catch {
                          setStorageError(true);
                        }
                        setSettingsOpen(false);
                      } catch {
                        setEndpointError(true);
                      }
                    }}
                  >
                    {t("saveSettings")}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            <ImportDialog onImport={imported} />
          </div>
        </header>
        <main className="p-4 md:p-6 pb-44 md:pb-28">
          <div className="flex flex-wrap justify-between items-end gap-4 mb-6">
            <div>
              <p className="text-xs text-muted-foreground mb-2 flex items-center gap-2">
                <span className="size-1.5 rounded-full bg-success" />
                {t("greeting")}
              </p>
              <h1 className="text-2xl font-semibold tracking-tight">
                {t("studyHeading")}
              </h1>
              <p className="text-muted-foreground mt-2 leading-5">
                {t("studySubtitle")}
              </p>
            </div>
            <div className="flex items-center gap-2 text-xs border rounded-md px-3 py-2 bg-card">
              <Target className="size-4 text-primary" aria-hidden="true" />
              {t("shortGoal", { count: goal })}
              <span className="text-muted-foreground ms-2">
                {fmt(dailyCount)} / {fmt(goal)}
              </span>
            </div>
          </div>
          {storageError && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle aria-hidden="true" />
              <AlertDescription>{t("storageError")}</AlertDescription>
            </Alert>
          )}
          <div className="print-hidden flex md:hidden justify-between gap-3 mb-4">
            <Dialog open={mobileOpen} onOpenChange={setMobileOpen}>
              <DialogTrigger asChild>
                <Button variant="outline">
                  <Menu aria-hidden="true" />
                  {t("menu")}
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card max-h-[90dvh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>{t("library")}</DialogTitle>
                  <DialogDescription>{t("selectLibrary")}</DialogDescription>
                </DialogHeader>
                {libraryList}
                {queuePanel("mobile")}
              </DialogContent>
            </Dialog>
            <Select
              value={collection === "stars" ? "daily" : collection}
              onValueChange={switchCollection}
            >
              <SelectTrigger aria-label={t("selectLibrary")} className="w-44">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {collections.map((c) => (
                  <SelectItem key={c.id} value={c.id}>
                    {c.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-[220px_minmax(0,1fr)] lg:grid-cols-[220px_minmax(0,1fr)_208px] gap-4 items-start">
            <div className="print-hidden hidden md:block">
              {queuePanel("desktop")}
            </div>
            <div className="min-w-0">
              {word ? (
                <article className="rounded-md border bg-card shadow-xs overflow-hidden">
                  <div className="px-5 md:px-6 py-5 border-b">
                    <div className="flex justify-between items-center gap-3">
                      <div className="flex gap-2 items-center">
                        <Badge variant="secondary">
                          {t(
                            word.category === "lookup"
                              ? "lookupEntry"
                              : word.category === "import"
                                ? "created"
                                : "tag",
                          )}
                        </Badge>
                        {word.level && (
                          <span className="text-xs text-muted-foreground">
                            {word.level}
                          </span>
                        )}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        aria-label={starred ? t("bookmarked") : t("bookmark")}
                        aria-pressed={!!starred}
                        onClick={favorite}
                      >
                        <Bookmark
                          className={starred ? "fill-primary text-primary" : ""}
                          aria-hidden="true"
                        />
                      </Button>
                    </div>
                    <div className="mt-5 flex items-center justify-between gap-3">
                      <h2 className="text-4xl font-semibold tracking-tight break-all">
                        {word.word}
                      </h2>
                      <Button
                        variant="secondary"
                        size="icon"
                        aria-label={t("listen")}
                        onClick={() => void audio.play([word.word])}
                      >
                        <Volume2 aria-hidden="true" />
                      </Button>
                    </div>
                    <div className="flex flex-wrap items-center gap-3 mt-3">
                      <span className="text-muted-foreground font-mono text-sm">
                        {word.phonetic}
                      </span>
                      {word.pos && (
                        <Badge variant="outline" className="font-normal">
                          {word.pos}
                        </Badge>
                      )}
                      <span className="text-xs text-muted-foreground ms-auto">
                        {voice.startsWith("en-GB")
                          ? t("voiceRyan")
                          : voice === "en-US-JennyNeural"
                            ? t("voiceJenny")
                            : t("voiceAria")}
                      </span>
                    </div>
                  </div>
                  <div className="px-5 md:px-6 py-5 space-y-6">
                    <section>
                      <h3 className="flex items-center gap-2 font-semibold mb-3">
                        <BookOpen
                          className="size-4 text-primary"
                          aria-hidden="true"
                        />
                        {t("definition")}
                      </h3>
                      <p className="text-base font-medium leading-7">
                        {word.meaning}
                      </p>
                      <p className="text-muted-foreground leading-7 mt-2">
                        {word.explanation || t("explainMissing")}
                      </p>
                    </section>
                    {word.phrases.length > 0 && (
                      <section>
                        <h3 className="text-xs text-muted-foreground mb-3">
                          {t("phrases")}
                        </h3>
                        <div className="flex flex-wrap gap-2">
                          {word.phrases.map((p) => (
                            <span
                              key={p}
                              className="border rounded-sm px-2 py-1 text-xs bg-muted/40"
                            >
                              {p}
                            </span>
                          ))}
                        </div>
                      </section>
                    )}
                    <section>
                      <div className="flex justify-between gap-2 items-center mb-3">
                        <h3 className="font-semibold flex items-center gap-2">
                          <Volume2
                            className="size-4 text-primary"
                            aria-hidden="true"
                          />
                          {t("examples")}
                        </h3>
                        <span className="text-xs text-muted-foreground">
                          {fmt(word.examples.length)}
                        </span>
                      </div>
                      {word.examples.length ? (
                        word.examples.map((e, i) => (
                          <div
                            className="bg-muted/50 border rounded-md p-4 mt-3"
                            key={i}
                          >
                            <div className="flex gap-3 items-start">
                              <span className="text-primary font-mono text-xs mt-1">
                                {String(i + 1).padStart(2, "0")}
                              </span>
                              <div className="min-w-0 flex-1">
                                <p className="text-base leading-7">{e.text}</p>
                                <p className="text-xs text-muted-foreground mt-2 leading-6">
                                  {e.translation || t("translationMissing")}
                                </p>
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                aria-label={t("listenExample", {
                                  count: i + 1,
                                })}
                                onClick={() => void audio.play([e.text])}
                              >
                                <Play aria-hidden="true" />
                              </Button>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-muted-foreground leading-6">
                          {t("exampleMissing")}
                        </p>
                      )}
                    </section>
                  </div>
                  {word.sources?.length ? (
                    <section className="border-t px-5 md:px-6 py-3">
                      <h3 className="text-xs text-muted-foreground">
                        {t("lookupSources")}
                      </h3>
                      {word.sources.map((source) => (
                        <Button
                          key={source.url}
                          variant="link"
                          size="sm"
                          className="min-h-11 md:min-h-8 h-auto whitespace-normal text-start"
                          asChild
                        >
                          <a href={source.url} target="_blank" rel="noreferrer">
                            {source.name}
                          </a>
                        </Button>
                      ))}
                      {word.missingFields?.length ? (
                        <p className="text-xs leading-5 text-muted-foreground">
                          {t("lookupMissing", {
                            fields: word.missingFields
                              .map((f) => t(f as CopyKey))
                              .join("、"),
                          })}
                        </p>
                      ) : null}
                    </section>
                  ) : null}
                  <div className="print-hidden border-t px-5 md:px-6 py-4 flex flex-wrap justify-between items-center gap-3">
                    <span className="text-xs text-muted-foreground">
                      {t("number", { current: index + 1, total: words.length })}
                    </span>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="icon"
                        aria-label={t("back")}
                        disabled={index === 0}
                        onClick={() => navigate(-1)}
                      >
                        <ArrowLeft aria-hidden="true" />
                      </Button>
                      <Button
                        variant={mastered ? "secondary" : "default"}
                        onClick={mark}
                      >
                        <Check aria-hidden="true" />
                        {mastered ? t("familiar") : t("mark")}
                      </Button>
                      <Button
                        variant="outline"
                        size="icon"
                        aria-label={t("next")}
                        disabled={index === words.length - 1}
                        onClick={() => navigate(1)}
                      >
                        <ArrowRight aria-hidden="true" />
                      </Button>
                    </div>
                  </div>
                </article>
              ) : (
                <section className="border rounded-md bg-card p-12 text-center">
                  <BookOpen
                    className="mx-auto size-8 text-muted-foreground mb-4"
                    aria-hidden="true"
                  />
                  <h2 className="font-semibold">
                    {lookup.loading ? t("lookupLoading") : t("wordMissing")}
                  </h2>
                  {lookup.loading && (
                    <div className="space-y-3 mt-4">
                      <Skeleton className="h-5 w-full" />
                      <Skeleton className="h-5 w-3/4" />
                      <Skeleton className="h-24 w-full" />
                    </div>
                  )}
                  <p className="text-muted-foreground mt-2">{t("emptyHelp")}</p>
                  <Button
                    className="mt-4"
                    variant="outline"
                    onClick={() => switchCollection("daily")}
                  >
                    {t("all")}
                  </Button>
                </section>
              )}
            </div>
            <aside className="hidden lg:block space-y-4 min-w-0">
              <section className="border bg-card rounded-md p-4">
                <h2 className="font-semibold flex items-center gap-2">
                  <Target className="size-4 text-primary" aria-hidden="true" />
                  {t("goal")}
                </h2>
                <div className="flex items-baseline gap-1 mt-5">
                  <span className="text-4xl font-semibold tabular-nums">
                    {fmt(dailyCount)}
                  </span>
                  <span className="text-muted-foreground">/ {fmt(goal)}</span>
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  {t("today")}
                </p>
                <Progress
                  className="h-1.5 mt-4"
                  value={Math.min((dailyCount / goal) * 100, 100)}
                />
                <p className="mt-3 text-xs text-muted-foreground leading-5">
                  {dailyCount >= goal ? t("complete") : t("minute")}
                </p>
                <div className="border-t mt-4 pt-4 flex justify-between items-center text-xs">
                  <span className="text-muted-foreground">{t("mastered")}</span>
                  <span className="font-medium">
                    {fmt(knownCount)} / {fmt(currentCollection.words.length)}
                  </span>
                </div>
              </section>
              <section className="border rounded-md p-4 bg-secondary/40">
                <h2 className="font-semibold flex gap-2 items-center text-secondary-foreground">
                  <Lightbulb className="size-4" aria-hidden="true" />
                  {t("help")}
                </h2>
                <p className="leading-6 text-xs text-muted-foreground mt-3">
                  {t("helpText")}
                </p>
              </section>
              {word && (
                <section className="border bg-card rounded-md p-4">
                  <h2 className="font-semibold mb-3">{t("note")}</h2>
                  <label className="sr-only" htmlFor="word-note">
                    {t("note")}
                  </label>
                  <Textarea
                    id="word-note"
                    className="min-h-36 text-xs"
                    placeholder={t("notePlaceholder")}
                    maxLength={3000}
                    value={saved.notes[word.id] || ""}
                    onChange={(e) =>
                      persist({
                        ...saved,
                        notes: { ...saved.notes, [word.id]: e.target.value },
                      })
                    }
                  />
                  <p className="mt-3 text-xs text-muted-foreground flex items-center gap-1">
                    <Check className="size-3" aria-hidden="true" />
                    {t("notesSaved")}
                  </p>
                </section>
              )}
            </aside>
          </div>
          <p className="text-center text-xs text-muted-foreground mt-6">
            {t("noteTip")}
          </p>
        </main>
        <footer
          className="print-hidden fixed bottom-0 end-0 start-0 md:start-16 xl:start-48 border-t bg-card z-30 px-4 md:px-6 py-3"
          aria-label={t("audio")}
        >
          <div className="flex flex-wrap items-center gap-3 md:gap-4">
            <div className="size-10 bg-secondary text-primary rounded-md flex items-center justify-center shrink-0">
              <Headphones className="size-5" aria-hidden="true" />
            </div>
            <div className="min-w-0 flex-1 md:flex-none md:w-40">
              <p className="font-medium truncate">
                {audio.text || word?.word || t("audio")}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {audio.status === "loading"
                  ? t("audioLoading")
                  : t("audioReady")}
              </p>
            </div>
            <Button
              size="icon"
              aria-label={audio.status === "playing" ? t("pause") : t("play")}
              disabled={!word || audio.status === "loading"}
              onClick={() => {
                if (["playing", "paused"].includes(audio.status))
                  audio.toggle();
                else if (word) void audio.play([word.word]);
              }}
            >
              {audio.status === "loading" ? (
                <Clock3 aria-hidden="true" />
              ) : audio.status === "playing" ? (
                <Pause aria-hidden="true" />
              ) : (
                <Play aria-hidden="true" />
              )}
            </Button>
            <div className="hidden md:flex flex-1 min-w-0 items-center gap-3">
              <span className="text-xs tabular-nums text-muted-foreground">
                {stamp(audio.time)}
              </span>
              <input
                type="range"
                className="w-full accent-primary h-8 cursor-pointer focus-visible:outline focus-visible:outline-2 focus-visible:outline-ring"
                min="0"
                max="100"
                value={audio.progress}
                onChange={(e) => audio.seek(Number(e.target.value))}
                aria-label={t("progress")}
                disabled={!audio.duration}
              />
              <span className="text-xs tabular-nums text-muted-foreground">
                {stamp(audio.duration)}
              </span>
            </div>
            <Select value={rate} onValueChange={setRate}>
              <SelectTrigger className="w-24" aria-label={t("speed")}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {[
                  ["0.75", "rateSlow"],
                  ["1", "rateNormal"],
                  ["1.25", "rateFast"],
                ].map(([v, k]) => (
                  <SelectItem key={v} value={v}>
                    {t(k as CopyKey)}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant={audio.repeat ? "secondary" : "ghost"}
              size="icon"
              aria-label={t("repeat")}
              aria-pressed={audio.repeat}
              onClick={audio.toggleRepeat}
            >
              <Repeat2 aria-hidden="true" />
            </Button>
            <Button
              className="hidden lg:inline-flex"
              variant="outline"
              disabled={!word || audio.status === "loading"}
              onClick={() =>
                word &&
                void audio.play([
                  word.word,
                  ...word.examples.map((e) => e.text),
                ])
              }
            >
              <Volume2 aria-hidden="true" />
              {t("playAll")}
            </Button>
          </div>
          {audio.status === "loading" && (
            <Skeleton className="h-1 mt-2 w-full" />
          )}
          {audio.status === "error" && (
            <div
              role="alert"
              className="text-destructive flex items-center gap-2 text-xs mt-2"
            >
              <AlertCircle className="size-4 shrink-0" aria-hidden="true" />
              <span>{t("audioFailed")}</span>
              <Button
                variant="link"
                size="sm"
                onClick={() => void audio.retry()}
              >
                {t("retry")}
              </Button>
            </div>
          )}
          <audio
            ref={audio.element}
            onEnded={audio.ended}
            onTimeUpdate={audio.update}
            onLoadedMetadata={audio.update}
            onError={audio.failed}
          />
        </footer>
        {notice && (
          <div
            role="status"
            className="fixed bottom-24 end-6 z-50 rounded-md border bg-card shadow-sm px-4 py-3 text-success flex gap-2 items-center"
          >
            <CheckCircle2 className="size-4" aria-hidden="true" />
            {notice}
          </div>
        )}
      </div>
    </div>
  );
}
