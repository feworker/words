import { useEffect, useRef, useState } from "react";
import { serviceURL } from "@/lib/service";
export function useAudio(voice: string, rate: number, endpoint: string) {
  const element = useRef<HTMLAudioElement>(null);
  const manifest = useRef<Record<string, string>>({});
  const cache = useRef(new Map<string, string>());
  const token = useRef(0);
  const queue = useRef<string[]>([]);
  const current = useRef("");
  const repeating = useRef(false);
  const [status, setStatus] = useState<
    "idle" | "loading" | "playing" | "paused" | "error"
  >("idle");
  const [text, setText] = useState("");
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [time, setTime] = useState(0);
  const [repeat, setRepeat] = useState(false);
  useEffect(() => {
    fetch(`${import.meta.env.BASE_URL}assets/audio-manifest.json`)
      .then((r) => r.json())
      .then((x) => {
        manifest.current = x;
      })
      .catch(() => {});
    return () => {
      token.current++;
      for (const url of cache.current.values()) URL.revokeObjectURL(url);
    };
  }, []);
  useEffect(() => {
    if (element.current) element.current.playbackRate = rate;
  }, [rate]);
  useEffect(() => {
    stop();
  }, [voice, endpoint]);
  function stop() {
    token.current++;
    queue.current = [];
    element.current?.pause();
    if (element.current) {
      element.current.removeAttribute("src");
      element.current.load();
    }
    current.current = "";
    setText("");
    setStatus("idle");
    setProgress(0);
    setTime(0);
    setDuration(0);
  }
  async function play(texts: string[]) {
    if (!texts.length) return;
    const serial = ++token.current;
    queue.current = texts.slice(1);
    current.current = texts[0];
    setText(texts[0]);
    setStatus("loading");
    setProgress(0);
    setTime(0);
    element.current?.pause();
    try {
      const key = voice + "|" + texts[0];
      let url = manifest.current[key]
        ? `${import.meta.env.BASE_URL}${manifest.current[key]}`
        : cache.current.get(endpoint + "|" + key);
      if (!url) {
        const service = serviceURL(endpoint, "tts");
        if (!service) throw new Error("service_unconfigured");
        const response = await fetch(service, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: texts[0], voice }),
          signal: AbortSignal.timeout(50000),
        });
        if (
          !response.ok ||
          !response.headers.get("content-type")?.includes("audio")
        )
          throw new Error("tts");
        const blob = await response.blob();
        url = URL.createObjectURL(blob);
        cache.current.set(endpoint + "|" + key, url);
      }
      if (serial !== token.current) return;
      const audio = element.current;
      if (!audio) return;
      audio.src = url;
      audio.playbackRate = rate;
      await audio.play();
      if (serial === token.current) setStatus("playing");
    } catch {
      if (serial === token.current) setStatus("error");
    }
  }
  function toggle() {
    const audio = element.current;
    if (!audio) return;
    if (status === "playing") {
      audio.pause();
      setStatus("paused");
    } else if (status === "paused") {
      audio
        .play()
        .then(() => setStatus("playing"))
        .catch(() => setStatus("error"));
    } else if (current.current) void play([current.current]);
  }
  function toggleRepeat() {
    repeating.current = !repeating.current;
    setRepeat(repeating.current);
  }
  function ended() {
    if (queue.current.length) void play(queue.current);
    else if (repeating.current) void play([current.current]);
    else {
      setStatus("idle");
      setProgress(100);
    }
  }
  function update() {
    const a = element.current;
    if (a) {
      setDuration(Number.isFinite(a.duration) ? a.duration : 0);
      setTime(a.currentTime);
      setProgress(a.duration ? (a.currentTime / a.duration) * 100 : 0);
    }
  }
  function seek(n: number) {
    if (element.current && element.current.duration)
      element.current.currentTime = (n / 100) * element.current.duration;
  }
  function failed() {
    setStatus("error");
  }
  return {
    element,
    failed,
    status,
    text,
    progress,
    duration,
    time,
    repeat,
    play,
    toggle,
    toggleRepeat,
    stop,
    ended,
    update,
    seek,
    retry: () => play([current.current]),
  };
}
