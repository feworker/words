import { useRef, useState, useEffect } from "react";
import { t } from "@/lib/i18n";
import type { Word } from "@/lib/words";
import { serviceURL } from "@/lib/service";
export function useWordLookup(endpoint: string) {
  const [loading, setLoading] = useState(false),
    [error, setError] = useState("");
  const controller = useRef<AbortController | null>(null),
    serial = useRef(0);
  function cancel() {
    serial.current++;
    controller.current?.abort();
    setLoading(false);
    setError("");
  }
  useEffect(
    () => () => {
      serial.current++;
      controller.current?.abort();
    },
    [],
  );
  async function run(value: string, onResult: (word: Word) => void) {
    cancel();
    const request = ++serial.current;
    const word = value.trim().toLowerCase();
    if (!/^[a-z]+(?:[-'][a-z]+)*$/.test(word) || word.length > 64) {
      setError(t("lookupInvalid"));
      return;
    }
    const url = serviceURL(endpoint, "lookup");
    if (!url) {
      setError(t("lookupUnconfigured"));
      return;
    }
    const abort = new AbortController();
    controller.current = abort;
    setLoading(true);
    const timeout = setTimeout(() => abort.abort(), 25000);
    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ word }),
        signal: abort.signal,
      });
      const data = await response.json();
      if (!response.ok)
        throw new Error(
          data.error === "not_found" ? t("lookupNotFound") : t("lookupFailed"),
        );
      if (
        typeof data.word !== "string" ||
        !data.meaning ||
        !Array.isArray(data.examples)
      )
        throw new Error(t("lookupFailed"));
      if (request !== serial.current) return;
      onResult({ ...data, id: crypto.randomUUID() });
    } catch (e) {
      if (request === serial.current)
        setError(
          e instanceof Error && e.message === t("lookupNotFound")
            ? t("lookupNotFound")
            : t("lookupFailed"),
        );
    } finally {
      clearTimeout(timeout);
      if (request === serial.current) setLoading(false);
    }
  }
  return { loading, error, run, cancel };
}
