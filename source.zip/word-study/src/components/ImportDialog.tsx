import { useState } from "react";
import {
  Download,
  FileText,
  Upload,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { t } from "@/lib/i18n";
import { download, parseWords, template } from "@/lib/import";
import type { Collection, Word } from "@/lib/words";
export default function ImportDialog({
  onImport,
}: {
  onImport: (c: Collection) => void;
}) {
  const [open, setOpen] = useState(false),
    [name, setName] = useState(""),
    [text, setText] = useState(""),
    [preview, setPreview] = useState<Word[]>([]),
    [error, setError] = useState(""),
    [reading, setReading] = useState(false);
  const change = (value: string) => {
    setText(value);
    setPreview([]);
    setError("");
  };
  async function read(file?: File) {
    if (!file) return;
    setPreview([]);
    if (file.size > 5 * 1024 * 1024) {
      setError(t("fileTooLarge"));
      return;
    }
    setReading(true);
    try {
      change(await file.text());
      if (!name) setName(file.name.replace(/\.(csv|json)$/i, ""));
    } catch {
      setError(t("importError"));
    } finally {
      setReading(false);
    }
  }
  function validate() {
    try {
      setPreview(parseWords(text));
      setError("");
    } catch (e) {
      setPreview([]);
      setError(e instanceof Error ? e.message : t("importError"));
    }
  }
  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (v) {
          setName("");
          setText("");
          setPreview([]);
          setError("");
        }
      }}
    >
      <DialogTrigger asChild>
        <Button variant="outline">
          <Upload aria-hidden="true" />
          {t("import")}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90dvh] overflow-y-auto bg-card">
        <DialogHeader>
          <DialogTitle>{t("import")}</DialogTitle>
          <DialogDescription>{t("importDescription")}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="library-name" className="font-medium">
              {t("importName")}
            </label>
            <Input
              id="library-name"
              maxLength={80}
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={t("importNamePlaceholder")}
            />
          </div>
          <div
            className="rounded-md border border-dashed p-4 space-y-3"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              void read(e.dataTransfer.files[0]);
            }}
          >
            <div className="flex items-center gap-3">
              <FileText className="size-5 text-primary" aria-hidden="true" />
              <div>
                <label htmlFor="word-file" className="font-medium">
                  {t("fileLabel")}
                </label>
                <p className="text-xs text-muted-foreground mt-1">
                  {t("fileHint")}
                </p>
              </div>
            </div>
            <Input
              id="word-file"
              type="file"
              accept=".csv,.json,text/csv,application/json"
              disabled={reading}
              onChange={(e) => void read(e.target.files?.[0])}
            />
            <Button
              variant="link"
              size="sm"
              className="px-0"
              onClick={() =>
                download(
                  "word-library.csv",
                  "\uFEFF" + template,
                  "text/csv;charset=utf-8",
                )
              }
            >
              <Download aria-hidden="true" />
              {t("download")}
            </Button>
          </div>
          <div className="space-y-2">
            <label htmlFor="import-text" className="font-medium">
              {t("importPaste")}
            </label>
            <Textarea
              id="import-text"
              aria-invalid={!!error}
              aria-describedby={error ? "import-error" : undefined}
              className="min-h-28 font-mono text-xs"
              value={text}
              onChange={(e) => change(e.target.value)}
              placeholder={t("importPlaceholder")}
            />
            <p className="text-xs leading-5 text-muted-foreground">
              {t("importFields")}
            </p>
          </div>
          {error && (
            <Alert id="import-error" variant="destructive">
              <AlertCircle aria-hidden="true" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          {preview.length > 0 && (
            <div className="rounded-md border bg-muted/40 p-3 space-y-3">
              <p className="flex items-center gap-2 font-medium text-success">
                <CheckCircle2 className="size-4" aria-hidden="true" />
                {t("previewCount", { count: preview.length })}
              </p>
              {preview.slice(0, 3).map((w) => (
                <div key={w.id} className="flex justify-between gap-4">
                  <span className="font-medium">{w.word}</span>
                  <span className="text-muted-foreground">{w.meaning}</span>
                </div>
              ))}
              <p className="text-xs text-muted-foreground">
                {t("previewHint")}
              </p>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button
            variant="outline"
            disabled={!text.trim() || reading}
            onClick={validate}
          >
            {reading ? t("fileRead") : t("importPreview")}
          </Button>
          <Button
            disabled={!preview.length}
            onClick={() => {
              onImport({
                id: crypto.randomUUID(),
                name: name.trim() || t("defaultName"),
                words: preview,
              });
              setOpen(false);
            }}
          >
            {t("importAction")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
