import Papa from "papaparse";
import { t } from "./i18n";
import type { Word } from "./words";
export function parseWords(text: string): Word[] {
  if (!text.trim()) throw new Error(t("importEmpty"));
  let rows: unknown[];
  if (text.trim().startsWith("[") || text.trim().startsWith("{")) {
    try {
      const parsed: unknown = JSON.parse(text);
      if (!Array.isArray(parsed)) throw new Error();
      rows = parsed;
    } catch {
      throw new Error(t("invalidJSON"));
    }
  } else {
    const result = Papa.parse<Record<string, unknown>>(text.trim(), {
      header: true,
      skipEmptyLines: "greedy",
      transformHeader: (h) => h.trim().replace(/^\uFEFF/, ""),
    });
    if (result.errors.length) throw new Error(t("invalidCSV"));
    rows = result.data;
  }
  if (rows.length > 2000) throw new Error(t("tooMany"));
  const seen = new Set<string>();
  const str = (x: unknown) => (typeof x === "string" ? x.trim() : "");
  return rows.map((value, i) => {
    if (!value || typeof value !== "object")
      throw new Error(t("invalidRow", { row: i + 1 }));
    const r = value as Record<string, unknown>;
    const word = str(r.word);
    const meaning = str(r.meaning);
    if (!word || !meaning || word.length > 120 || meaning.length > 2000)
      throw new Error(t("invalidRow", { row: i + 1 }));
    if (seen.has(word.toLowerCase())) throw new Error(t("duplicate", { word }));
    seen.add(word.toLowerCase());
    const examples = Array.isArray(r.examples)
      ? r.examples
          .filter(
            (e): e is Record<string, unknown> => !!e && typeof e === "object",
          )
          .map((e) => ({ text: str(e.text), translation: str(e.translation) }))
          .filter((e) => e.text)
      : str(r.example)
        ? [{ text: str(r.example), translation: str(r.translation) }]
        : [];
    if (examples.length > 10 || examples.some((e) => e.text.length > 1200))
      throw new Error(t("invalidRow", { row: i + 1 }));
    return {
      id: crypto.randomUUID(),
      word,
      meaning,
      phonetic: str(r.phonetic),
      pos: str(r.pos),
      explanation: str(r.explanation).slice(0, 4000),
      examples,
      phrases: Array.isArray(r.phrases)
        ? r.phrases
            .filter((p): p is string => typeof p === "string")
            .slice(0, 10)
        : str(r.phrases)
          ? str(r.phrases).split("|")
          : [],
      level: str(r.level),
      category: "import",
    };
  });
}
export function download(name: string, contents: string, type: string) {
  const url = URL.createObjectURL(new Blob([contents], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export const template =
  "word,phonetic,pos,meaning,explanation,example,translation\ncurious,/ˈkjʊr.i.əs/,adj.,好奇的,be curious about 表示对某事好奇。,Stay curious and keep asking questions.,保持好奇并不断提问。\n";
