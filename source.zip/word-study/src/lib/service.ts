declare global {
  interface Window {
    WORDS_SERVICE_ENDPOINT?: string;
  }
}
export function validService(value: string) {
  if (!value) return true;
  try {
    const url = new URL(value);
    return (
      !url.username &&
      !url.password &&
      !url.search &&
      !url.hash &&
      (url.protocol === "https:" ||
        (import.meta.env.DEV && url.protocol === "http:"))
    );
  } catch {
    return false;
  }
}
export function loadService() {
  let value = window.WORDS_SERVICE_ENDPOINT || "";
  try {
    value = localStorage.getItem("word-study-service") ?? value;
  } catch {
    /* Browser storage may be unavailable. */
  }
  return validService(value) ? value : "";
}
export function serviceURL(endpoint: string, path: string) {
  if (!endpoint && !import.meta.env.DEV) return null;
  return `${endpoint.replace(/\/$/, "")}/api/${path}`;
}
