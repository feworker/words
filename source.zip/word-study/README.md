# 词间 · 英语单词学习

React + TypeScript + Vite 本地学习应用。界面采用 shadcn/ui、Tailwind、CVA 和 lucide，默认中文，支持深浅主题、键盘操作和响应式布局。

## 启动

需要 Node.js 20.19+（或 22.12+）和 Python 3.10+。

```bash
npm install
npm start
```

打开 http://127.0.0.1:5173/ 。首次启动会创建项目内的 `.venv` 并安装 `edge-tts`，随后同时启动前端与本地音频服务。使用 `Ctrl+C` 停止。前端端口为 5173，音频服务端口为 8787；两者需要空闲。

```bash
npm test
python3 -m unittest discover -s server -p 'test_*.py' -v
npm run typecheck
npm run build
```

## 已实现

- 单词列表、本地筛选、联网查词自动入库、词库切换、待学习/已掌握筛选。
- 音标、词性、词义、讲解、常见搭配、英文例句和中文译文。
- CSV / JSON 文件导入、拖放、粘贴、格式校验、预览、导入后直接学习。
- 示例词库下载与当前词库 JSON 导出。单次最多 2,000 词，文件最多 5 MB。
- 收藏、掌握标记、每日目标、统计和个人笔记，保存在当前浏览器 localStorage。
- 微软语音：单词发音、例句播放、暂停/继续、进度跳转、0.75/1/1.25 倍速、单条循环、单词及例句连播。
- Jenny / Aria 美式女声、Ryan 英式男声，以及可配置的音频服务地址。
- 深浅主题、减少动效选项、弹窗焦点管理、手机与平板布局、学习卡打印样式。

## 联网查词与自动入库

在搜索框输入一个英文单词，按回车或点击“查词并入库”。输入过程仍筛选当前词库；提交后才联网查询，避免把未输入完整的词片段存入词库。支持英文连字符和撇号，最长 64 字符；中文可用于本地筛选，不能作为联网查词提交。

本地服务查询有道公开在线词典，读取中文释义、词性、英美音标（优先美式）、词典讲解及词源、最多 6 个常见搭配与 3 条双语例句，并保存可点击的资料来源。新词自动加入“查词生词本”；已有完整词直接定位，已有导入词缺项时补齐原词条，保留原释义和已填写内容。手机查询成功后关闭词库弹窗，直接显示词卡。

条目保存在当前浏览器，刷新后可从词库中再次选择。查询结果在服务端缓存 7 天；词典未提供的字段明确标注，不生成虚构资料。未找到词或网络失败时显示可重试错误，不新增无效词条。编辑搜索或切换词库会取消尚未完成的查询，避免旧结果覆盖新选择。

新词与例句点击播放时继续调用 Microsoft TTS 生成音频。联网补全需要网络及本地服务；第三方词典的覆盖范围和接口可用性会影响结果，少见词不一定有全部字段。本实现使用在线词典检索，不生成搜索引擎网页摘要。

接口：`POST /api/lookup`，请求 `{ "word": "abundant" }`，成功返回词库字段、`sources` 和 `missingFields`；错误代码 `invalid_word` / `not_found` / `lookup_unavailable` 分别对应 400 / 404 / 502。

## 微软 TTS

默认通过服务端 `edge-tts` 使用 Microsoft Edge 在线神经语音。实际生成 MP3，没有使用 `speechSynthesis` 或用系统语音冒充微软语音。预置 12 个单词、18 条例句，共 30 段 Jenny 音频，放在 `public/audio/` 中，可直接播放。

新导入文本或其他声音需要联网调用本地服务生成音频。服务将英文文本发往微软并缓存 MP3，浏览器不接触服务凭据。Edge 在线接口的可用性可能受网络或服务调整影响，错误时页面会提供重试入口。

如需正式的 Azure Speech 服务，可以在启动终端中设置 `AZURE_SPEECH_KEY` 和 `AZURE_SPEECH_REGION` 环境变量；服务检测到密钥后会使用 Azure 官方 TTS API。Azure 路径保留了服务端实现，本次实测的是默认 Edge TTS 路径。

远程音频服务需暴露 `POST /api/tts`，请求体为 `{ "text": "hello", "voice": "en-US-JennyNeural" }`，成功返回 `audio/mpeg`。默认服务仅监听本机并允许 localhost 开发页面。服务端的 `TTS_ALLOWED_ORIGINS` 可配置允许来源。这里交付的是本地版本，没有发布到 GitHub Pages。

## 词库格式

CSV 必填表头：`word,meaning`。可选：`phonetic,pos,explanation,example,translation,phrases,level`。`phrases` 使用 `|` 分隔，包含逗号的字段需用双引号包裹。

```csv
word,meaning,example,translation
curious,好奇的,Stay curious.,保持好奇。
```

JSON 为对象数组，支持多条例句：

```json
[
  {
    "word": "curious",
    "phonetic": "/ˈkjʊr.i.əs/",
    "pos": "adj.",
    "meaning": "好奇的",
    "explanation": "be curious about 表示对某事好奇。",
    "examples": [{"text": "Stay curious.", "translation": "保持好奇。"}],
    "phrases": ["be curious about"],
    "level": "A2"
  }
]
```

CSV 示例见 `public/sample-library.csv`，完整 JSON 示例见 `public/sample-library.json`。导入时读取文件提供的讲解和例句；缺失字段可在导入后搜索该词并按回车联网补全。不同词库可以包含同一个词，单个导入词库内不允许大小写不同的重复词。

## 数据与检查

学习数据仅保存在当前浏览器，不跨设备同步。浏览器清理存储后数据会消失，建议使用词库导出备份；存储失败时显示警告。导出文件包含词库内容，不包含个人掌握记录和笔记。

入口链路：`index.html → src/main.tsx → src/App.tsx → src/pages/HomePage.tsx`。

查看 `SELF-CHECK.md` 获取 16 项自检证据、功能测试与边界说明。`contrast-audit.json` 记录实际页面使用的文字对比度。


## GitHub Pages /words 部署

项目站点 https://feworker.github.io/words/ ，独立公开仓库 https://github.com/feworker/words 。与 english 一样使用 main 分支根目录部署，GitHub 自动把项目仓库映射到 /words/，无需改动 feworker.github.io 仓库。

执行 `npm run build:pages`，产物在 dist/：根目录 JS/CSS、音频清单、30 段 Microsoft Jenny MP3、公开配置 words-config.js。线上仓库包含构建产物及 source.zip 可运行源码快照；源码不含本机缓存、虚拟环境、学习记录或服务凭据。

Pages 只运行静态网页。未配置后端时，预置词与例句、导入、收藏、笔记、导出仍可使用；新词联网补全及非预置音频需要后端服务。可在播放设置中填写 HTTPS 服务基地址，或设置 words-config.js 的 window.WORDS_SERVICE_ENDPOINT。查词和语音共用该地址，设置保存在当前浏览器。

后端需支持 POST /api/lookup 和 POST /api/tts，且允许 https://feworker.github.io 跨域。Python 后端默认绑定本机；在服务器运行并经 HTTPS 反向代理提供后，设置 TTS_ALLOWED_ORIGINS=https://feworker.github.io。Azure 密钥只放后端环境变量。

当前 Edge 朗读 WebSocket 的浏览器直连验证未返回音频，未作为线上可用实现。默认提供真实预置微软音频，动态语音通过配置的服务生成。


## 浏览器标签页身份

标签页使用英语学习主题的 lucide BookOpen SVG 图标，currentColor 消费现有品牌 primary token，自动适配浏览器深浅色偏好。scripts/generate-favicon.mjs 在 dev/build 前从 globals.css 的两套 token 生成 public/favicon.svg，避免颜色重复维护。

首页标题为“英语单词学习 · 词间”，应用加载后随当前词库或收藏视图更新为“视图 · 英语单词学习 · 词间”；文案通过 i18n，html lang 与中文 locale 保持一致。资源使用 BASE_URL，在本地 /favicon.svg 和 Pages /words/favicon.svg 均可访问。

## GitHub Actions 离线音频构建

工作流 `.github/workflows/pages.yml` 在 main 的 source.zip 或工作流更新时运行，也支持手动运行。Pages 的 Source 必须选择 GitHub Actions。

构建解压 source.zip，使用锁定依赖，直接读取 `src/lib/words.ts` 的 samples（与页面共用同一数据）。`npm run audio:generate` 为全部词汇和英文例句生成 Jenny、Aria、Ryan 三种 Microsoft 神经语音 MP3。合成阶段需要访问微软服务；发布后浏览器从静态站点播放 MP3，无需 TTS 后端。使用 ffprobe 验证每个文件，失败重试，缺失音频则构建失败并保留上一次线上版本。缓存按文本、声音和格式版本复用。

新增词汇：修改 src/lib/words.ts，在本地更新 source.zip 后提交；Actions 自动补齐新 MP3。浏览器导入/搜索的词仅保存在该浏览器，需导出并加入仓库词库后重新构建才能获得静态音频。联网查词仍独立于此流程。

本地生成需 Python、edge-tts 与 ffprobe（FFmpeg），执行 npm run audio:generate，再执行 npm run build:pages。
