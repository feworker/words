# Actions 音频构建验收

工作流：https://github.com/feworker/words/blob/main/.github/workflows/pages.yml
成功运行：https://github.com/feworker/words/actions/runs/40313510456
源码提交：112fd4ea3a50ad0be9808958f23974e2de7ea20e

## 结果

GitHub runner 从源码提取 12 个词和 18 条英文例句，生成 Jenny、Aria、Ryan 共 90 个 MP3。90/90 经过 ffprobe 验证；本次全部新生成，未使用缓存音频。build 1m9s，deploy 32s，总时长 1m48s，最终 Success。Pages 已切换为 GitHub Actions。

首次运行的锁文件引用内部 npm 镜像，依赖安装失败；已改公共 registry.npmjs.org，保留版本和 integrity。公共 npm ci 和本地 build:pages 均通过。

## 验证

- 生成脚本：文本去重、三语音覆盖、真实 MP3 解码、缓存复用、损坏缓存拒绝、生成失败保留原 manifest，隔离临时目录测试通过。TTS 通信使用测试替身；真实合成由上述 GitHub Actions 验证。
- 本地 npm run build:pages：类型检查与 Vite 构建成功。
- 线上 Jenny serendipity：静态 4e599eb46e7836e16a107c7b.mp3，播放器进入播放状态并显示时长。
- 线上 Aria 第一句例句：静态 be87cedb8abd2e0e7b86d3fb.mp3，duration=3.672，paused=false，无媒体错误。
- 线上 Ryan serendipity：静态 f970289758f85f07ef4c506a.mp3，duration=1.896，无媒体错误。
- 截图：../words-actions-audio.jpg。

合成阶段连接微软服务；发布后的站点播放静态音频，不需要 TTS 后端。浏览器临时导入的词汇需加入源码词库并重建才能进入此离线音频流程。
