"""Offline regression tests for real dictionary response parsing and lookup failures."""
import unittest
from unittest.mock import patch
from urllib.error import URLError
from lookup import parse_entry, lookup_word, clean, LookupError


def fixture():
    return {
        'ec': {'word': [{'usphone': 'ˈtest', 'trs': [{'tr': [{'l': {'i': ['n. 测试', 'v. 测验']}}]}]}], 'exam_type': ['CET4']},
        'collins': {'collins_entries': [{'entries': {'entry': [{'tran_entry': [{'tran': '<b>A test</b> &amp; explanation. 测试说明', 'exam_sents': {'sent': [{'eng_sent': '<b>Take</b> a test.', 'chn_sent': '做一次测试。'}]}}]}]}}]},
        'blng_sents_part': {'sentence-pair': [{'sentence': 'Take a test.', 'sentence-translation': '做一次测试。'}]},
        'phrs': {'phrs': [{'phr': {'headword': {'l': {'i': 'take a test'}}}}]},
    }

class LookupTests(unittest.TestCase):
    def test_complete_entry_strips_html_and_keeps_all_meanings(self):
        entry = parse_entry(fixture(), 'test')
        self.assertEqual(entry['meaning'], '测试；测验')
        self.assertEqual(entry['phonetic'], '/ˈtest/')
        self.assertEqual(entry['pos'], 'n.')
        self.assertEqual(entry['explanation'], 'A test & explanation. 测试说明')
        self.assertEqual(entry['phrases'], ['take a test'])
        self.assertEqual(entry['missingFields'], [])
        self.assertEqual(entry['sources'][0]['url'], 'https://dict.youdao.com/result?word=test&lang=en')

    def test_duplicate_examples_are_removed(self):
        self.assertEqual(len(parse_entry(fixture(), 'test')['examples']), 1)

    def test_missing_material_is_reported_without_invention(self):
        result = parse_entry({'ec': {'word': [{'trs': [{'tr': [{'l': {'i': '测试'}}]}]}]}}, 'test')
        self.assertEqual(set(result['missingFields']), {'phonetic', 'pos', 'examples', 'phrases'})
        self.assertEqual(result['examples'], [])
        self.assertEqual(result['explanation'], '测试')

    def test_only_bilingual_examples_are_saved(self):
        data = fixture()
        data.pop('collins')
        data['blng_sents_part']['sentence-pair'][0].pop('sentence-translation')
        self.assertEqual(parse_entry(data, 'test')['examples'], [])

    def test_unknown_word(self):
        with self.assertRaises(LookupError) as raised:
            parse_entry({}, 'qzxqzx')
        self.assertEqual((raised.exception.code, raised.exception.status), ('not_found', 404))

    def test_invalid_input_never_calls_network(self):
        with patch('lookup.urlopen') as network:
            for value in [None, {}, '', 'hello world', '中文', '../secret', 'https://example.com', 'a' * 65]:
                with self.subTest(value=value), self.assertRaises(LookupError) as raised:
                    lookup_word(value)
                self.assertEqual(raised.exception.code, 'invalid_word')
            network.assert_not_called()

    def test_network_failure_maps_to_retryable_error(self):
        with patch('lookup.urlopen', side_effect=URLError('offline')):
            with self.assertRaises(LookupError) as raised:
                lookup_word('regressionwordqzx')
        self.assertEqual((raised.exception.code, raised.exception.status), ('lookup_unavailable', 502))

    def test_text_cleaning(self):
        self.assertEqual(clean('<b>Hello</b>\n &amp; world'), 'Hello & world')
        self.assertEqual(clean(None), '')

if __name__ == '__main__':
    unittest.main()
