"""Local Microsoft neural speech gateway. No credentials are sent to the browser."""
import asyncio
import hashlib
import json
import os
from pathlib import Path
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from xml.sax.saxutils import escape
import edge_tts
from lookup import lookup_word, LookupError

ROOT = Path(__file__).resolve().parent.parent
CACHE = ROOT / '.audio-cache'
CACHE.mkdir(exist_ok=True)
VOICES = {'en-US-JennyNeural', 'en-US-AriaNeural', 'en-GB-RyanNeural'}
ALLOWED = set(os.environ.get('TTS_ALLOWED_ORIGINS', 'http://127.0.0.1:5173,http://localhost:5173').split(','))
LOCK = threading.Lock()

async def speech(text, voice, path):
    await asyncio.wait_for(edge_tts.Communicate(text, voice).save(str(path)), timeout=40)

def synthesize(text, voice):
    target = CACHE / (hashlib.sha256((voice + '|' + text).encode()).hexdigest() + '.mp3')
    with LOCK:
        if target.exists() and target.stat().st_size > 500:
            return target.read_bytes()
        temp = target.with_suffix('.tmp')
        try:
            key = os.environ.get('AZURE_SPEECH_KEY')
            region = os.environ.get('AZURE_SPEECH_REGION', '')
            if key:
                if not region.isalnum():
                    raise ValueError('Invalid Azure region')
                language = 'en-GB' if voice.startswith('en-GB') else 'en-US'
                ssml = f'<speak version="1.0" xml:lang="{language}"><voice name="{voice}">{escape(text)}</voice></speak>'
                req = Request(f'https://{region}.tts.speech.microsoft.com/cognitiveservices/v1', data=ssml.encode(), headers={'Ocp-Apim-Subscription-Key': key, 'Content-Type': 'application/ssml+xml', 'X-Microsoft-OutputFormat': 'audio-24khz-48kbitrate-mono-mp3', 'User-Agent': 'WordStudy'}, method='POST')
                with urlopen(req, timeout=40) as result:
                    temp.write_bytes(result.read())
            else:
                asyncio.run(speech(text, voice, temp))
            if temp.stat().st_size < 500:
                raise RuntimeError('Empty audio')
            temp.replace(target)
            return target.read_bytes()
        finally:
            temp.unlink(missing_ok=True)

class Handler(BaseHTTPRequestHandler):
    def cors(self):
        origin = self.headers.get('Origin')
        if origin in ALLOWED:
            self.send_header('Access-Control-Allow-Origin', origin)
            self.send_header('Vary', 'Origin')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Allow-Methods', 'POST, OPTIONS')

    def reply(self, status, data, content_type='application/json'):
        self.send_response(status)
        self.cors()
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_OPTIONS(self):
        self.reply(204, b'')

    def do_GET(self):
        self.reply(200 if self.path == '/api/health' else 404, b'{"ok":true}' if self.path == '/api/health' else b'{"error":"not_found"}')

    def do_POST(self):
        if self.path not in {'/api/tts', '/api/lookup'}:
            return self.reply(404, b'{"error":"not_found"}')
        if self.headers.get('Origin') and self.headers.get('Origin') not in ALLOWED:
            return self.reply(403, b'{"error":"origin_not_allowed"}')
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if length < 1 or length > 20000:
                return self.reply(413, b'{"error":"request_too_large"}')
            payload = json.loads(self.rfile.read(length))
            if not isinstance(payload, dict):
                return self.reply(400, b'{"error":"invalid_input"}')
            if self.path == '/api/lookup':
                try:
                    result = lookup_word(payload.get('word'))
                    return self.reply(200, json.dumps(result, ensure_ascii=False).encode())
                except LookupError as error:
                    return self.reply(error.status, json.dumps({'error': error.code}).encode())
            text, voice = payload.get('text'), payload.get('voice')
            if not isinstance(text, str) or not 1 <= len(text.strip()) <= 1500 or voice not in VOICES:
                return self.reply(400, b'{"error":"invalid_input"}')
            data = synthesize(text.strip(), voice)
            self.reply(200, data, 'audio/mpeg')
        except (ValueError, json.JSONDecodeError):
            self.reply(400, b'{"error":"invalid_input"}')
        except Exception as error:
            print('Speech service error:', type(error).__name__, flush=True)
            self.reply(502, b'{"error":"speech_unavailable"}')

if __name__ == '__main__':
    print('Microsoft speech gateway: http://127.0.0.1:8787', flush=True)
    ThreadingHTTPServer(('127.0.0.1', 8787), Handler).serve_forever()
