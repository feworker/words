"""Read bilingual entries and examples from the online Youdao dictionary."""
import html
import json
import re
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen

CACHE = Path(__file__).resolve().parent.parent / '.word-cache'
CACHE.mkdir(exist_ok=True)

class LookupError(Exception):
    def __init__(self, code, status=502):
        self.code, self.status = code, status

def clean(value):
    if not isinstance(value, str):
        return ''
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]*>', '', value))).strip()[:4000]

def parse_entry(data, word):
    ec = data.get('ec', {})
    entries = ec.get('word', [])
    if not entries:
        raise LookupError('not_found', 404)
    entry = entries[0]
    definitions = []
    for group in entry.get('trs', []):
        for item in group.get('tr', []):
            values = item.get('l', {}).get('i', [])
            if isinstance(values, str): values = [values]
            definitions.extend(clean(v) for v in values if clean(v))
    if not definitions:
        raise LookupError('not_found', 404)
    pos = re.match(r'^([a-z]+\.)\s*', definitions[0])
    meaning = '；'.join(dict.fromkeys(re.sub(r'^[a-z]+\.\s*', '', item) for item in definitions))
    phonetic = entry.get('usphone') or entry.get('ukphone') or ''
    explanations = []
    examples = []
    for collins in data.get('collins', {}).get('collins_entries', []):
        phonetic = phonetic or collins.get('phonetic', '')
        for item in collins.get('entries', {}).get('entry', []):
            for tran in item.get('tran_entry', []):
                explanation = clean(tran.get('tran', ''))
                if explanation and len(explanations) < 3: explanations.append(explanation)
                for ex in tran.get('exam_sents', {}).get('sent', []):
                    text, translation = clean(ex.get('eng_sent')), clean(ex.get('chn_sent'))
                    if text and translation: examples.append({'text': text, 'translation': translation})
    for ex in data.get('blng_sents_part', {}).get('sentence-pair', []):
        text, translation = clean(ex.get('sentence') or ex.get('sentence-eng')), clean(ex.get('sentence-translation'))
        if text and translation: examples.append({'text': text, 'translation': translation})
    unique = {e['text']: e for e in examples if len(e['text']) <= 1200}
    phrases = []
    for item in data.get('phrs', {}).get('phrs', []):
        phrase = clean(item.get('phr', {}).get('headword', {}).get('l', {}).get('i'))
        if phrase and phrase not in phrases: phrases.append(phrase)
    etymology = data.get('etym', {}).get('etyms', {}).get('zh', [])
    if etymology:
        detail = clean(etymology[0].get('value'))
        if detail: explanations.append(detail)
    explanation = '\n'.join(explanations or definitions)
    source_url = 'https://dict.youdao.com/result?word=' + quote(word) + '&lang=en'
    result = {'word': word, 'phonetic': '/' + clean(phonetic).strip('/') + '/' if phonetic else '', 'pos': pos.group(1) if pos else '', 'meaning': meaning, 'explanation': explanation, 'examples': list(unique.values())[:3], 'phrases': phrases[:6], 'level': ' / '.join(ec.get('exam_type', [])[:2]), 'category': 'lookup', 'sources': [{'name': '有道词典（含双语词典与例句）', 'url': source_url}], 'missingFields': []}
    for field in ['phonetic', 'pos', 'examples', 'phrases']:
        if not result[field]: result['missingFields'].append(field)
    return result

def lookup_word(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z]+(?:[-'][A-Za-z]+)*", value.strip()) or len(value.strip()) > 64:
        raise LookupError('invalid_word', 400)
    word = value.strip().lower()
    cache = CACHE / (word + '.json')
    try:
        if cache.exists() and time.time() - cache.stat().st_mtime < 7 * 24 * 3600:
            return json.loads(cache.read_text())
    except (ValueError, OSError): pass
    try:
        request = Request('https://dict.youdao.com/jsonapi?q=' + quote(word), headers={'User-Agent': 'Mozilla/5.0 WordStudy/1.0'})
        with urlopen(request, timeout=18) as response:
            raw = response.read(2_000_001)
            if len(raw) > 2_000_000: raise LookupError('lookup_unavailable')
            data = json.loads(raw)
        result = parse_entry(data, word)
        try: cache.write_text(json.dumps(result, ensure_ascii=False))
        except OSError: pass
        return result
    except LookupError: raise
    except (HTTPError, URLError, TimeoutError, ValueError, KeyError, TypeError, AttributeError):
        raise LookupError('lookup_unavailable')
