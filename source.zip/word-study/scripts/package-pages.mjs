import fs from 'node:fs/promises';
import path from 'node:path';

const manifest = JSON.parse(await fs.readFile('dist/audio-manifest.json', 'utf8'));
for (const file of Object.values(manifest)) {
  if (!/^audio\/[a-z0-9]+\.mp3$/.test(file)) {
    throw new Error(`Audio must stay in the audio/ directory: ${file}`);
  }
  await fs.access(path.join('dist', file));
}
if ((await fs.readdir('dist')).some(file => file.endsWith('.mp3'))) {
  throw new Error('Root-level MP3 files are not allowed in the Pages artifact');
}
await fs.writeFile('dist/.nojekyll', '');
console.log(`Pages package: /words/ base, ${Object.keys(manifest).length} Microsoft MP3 files in audio/`);
