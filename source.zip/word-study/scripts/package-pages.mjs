import fs from 'node:fs/promises';
import path from 'node:path';
const manifest = JSON.parse(await fs.readFile('dist/audio-manifest.json', 'utf8'));
for (const [key, file] of Object.entries(manifest)) {
  const basename = path.basename(file);
  await fs.copyFile(path.join('dist', file), path.join('dist', basename));
  manifest[key] = basename;
}
await fs.writeFile('dist/audio-manifest.json', JSON.stringify(manifest, null, 2));
await fs.rm('dist/audio', { recursive: true, force: true });
await fs.writeFile('dist/.nojekyll', '');
console.log(`Pages package: /words/ base, ${Object.keys(manifest).length} Microsoft MP3 files`);
