import fs from "node:fs/promises";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { BookOpen } from "lucide-react";

// Favicons are separate SVG documents: copy the canonical theme tokens at build time.
const css = await fs.readFile("src/styles/globals.css", "utf8");
const primary = (selector) => {
  const start = css.indexOf(selector + " {");
  const block = css.slice(start, css.indexOf("}", start));
  const value = block.match(/--primary:\s*([^;]+);/)?.[1];
  if (!value) throw new Error("Missing brand token for " + selector);
  return value;
};
const theme = `<style>:root{--primary:${primary(":root")};color:hsl(var(--primary))}@media(prefers-color-scheme:dark){:root{--primary:${primary(".dark")};color:hsl(var(--primary))}}</style>`;
const svg = renderToStaticMarkup(
  createElement(BookOpen, {
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
  }),
).replace("</svg>", theme + "</svg>");
await fs.writeFile("public/favicon.svg", svg + "\n");
console.log("Favicon: lucide BookOpen, canonical light/dark brand tokens");
