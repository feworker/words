import { mkdir, writeFile } from 'node:fs/promises';
import { samples } from '../src/lib/words';
// Use the same words and examples rendered by the application, never a stale copy.
await mkdir('.build', { recursive: true });
await writeFile('.build/audio-words.json', JSON.stringify(samples, null, 2));
await writeFile('public/sample-library.json', JSON.stringify(samples, null, 2));
console.log(`Exported ${samples.length} words and ${samples.reduce((n, w) => n + w.examples.length, 0)} examples`);
