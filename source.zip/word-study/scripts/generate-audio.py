import asyncio
import hashlib
import json
import sys
from pathlib import Path
import edge_tts

async def main():
    root = Path(__file__).resolve().parent.parent
    words = json.loads(Path(sys.argv[1]).read_text())
    folder = root / 'public/audio'
    folder.mkdir(parents=True, exist_ok=True)
    manifest = {}
    for item in words:
        for text in [item['word']] + [e['text'] for e in item['examples']]:
            for voice in ['en-US-JennyNeural']:
                key = voice + '|' + text
                filename = hashlib.sha256(key.encode()).hexdigest()[:20] + '.mp3'
                target = folder / filename
                if not target.exists() or target.stat().st_size < 500:
                    await asyncio.wait_for(edge_tts.Communicate(text, voice).save(str(target)), timeout=45)
                manifest[key] = 'audio/' + filename
                (root / 'public/audio-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
                print(item['word'], target.stat().st_size, flush=True)

asyncio.run(main())
