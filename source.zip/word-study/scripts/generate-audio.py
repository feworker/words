"""Pre-generate and validate Microsoft MP3s; fail the build on incomplete audio."""
import asyncio
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import edge_tts

ROOT = Path(__file__).resolve().parent.parent
VOICES = ('en-US-JennyNeural', 'en-US-AriaNeural', 'en-GB-RyanNeural')
FOLDER = ROOT / 'public/audio'
FORMAT_VERSION = 'edge-tts-7.3.1-mp3-v1'


def valid_audio(path):
    if not path.is_file() or path.stat().st_size < 500:
        return False
    result = subprocess.run(
        ['ffprobe', '-v', 'error', '-select_streams', 'a:0',
         '-show_entries', 'stream=codec_name:format=duration', '-of', 'json', str(path)],
        capture_output=True, text=True, timeout=15,
    )
    if result.returncode:
        return False
    try:
        data = json.loads(result.stdout)
        return data['streams'][0]['codec_name'] == 'mp3' and float(data['format']['duration']) > 0
    except (KeyError, IndexError, ValueError):
        return False


async def main():
    words = json.loads(Path(sys.argv[1]).read_text())
    texts = set()
    for word in words:
        for text in [word['word']] + [example['text'] for example in word['examples']]:
            if not isinstance(text, str) or not text.strip():
                raise ValueError('Every word and example must have nonempty text')
            texts.add(text)
    if not texts:
        raise ValueError('The audio vocabulary is empty')
    FOLDER.mkdir(parents=True, exist_ok=True)
    semaphore = asyncio.Semaphore(2)
    manifest = {}
    counts = {'generated': 0, 'cached': 0}

    async def synthesize(voice, text):
        key = voice + '|' + text
        filename = hashlib.sha256((FORMAT_VERSION + '|' + key).encode()).hexdigest()[:24] + '.mp3'
        target = FOLDER / filename
        async with semaphore:
            if valid_audio(target):
                counts['cached'] += 1
            else:
                temporary = target.with_suffix('.tmp.mp3')
                for attempt in range(4):
                    try:
                        await asyncio.wait_for(edge_tts.Communicate(text, voice).save(str(temporary)), timeout=60)
                        if not valid_audio(temporary):
                            raise RuntimeError('Microsoft returned invalid MP3 audio')
                        temporary.replace(target)
                        counts['generated'] += 1
                        break
                    except Exception:
                        temporary.unlink(missing_ok=True)
                        if attempt == 3:
                            raise
                        await asyncio.sleep(2 ** attempt)
            manifest[key] = 'audio/' + filename
            print(f'{voice}: {text[:70]} ({target.stat().st_size} bytes)', flush=True)

    await asyncio.gather(*(synthesize(v, text) for v in VOICES for text in sorted(texts)))
    expected = len(texts) * len(VOICES)
    if len(manifest) != expected:
        raise RuntimeError(f'Audio coverage incomplete: {len(manifest)}/{expected}')
    # Publish the manifest only after every required file passes validation.
    output = ROOT / 'public/assets/audio-manifest.json'
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = output.with_suffix('.tmp.json')
    temporary.write_text(json.dumps(dict(sorted(manifest.items())), ensure_ascii=False, indent=2))
    temporary.replace(output)
    active = {Path(file).name for file in manifest.values()}
    for file in FOLDER.glob('*.mp3'):
        if file.name not in active:
            file.unlink()
    report = f'Microsoft audio: {len(words)} words, {len(texts)} unique texts, {len(VOICES)} voices, {expected}/{expected} verified MP3s; {counts["generated"]} generated, {counts["cached"]} cached.'
    print(report, flush=True)
    if os.environ.get('GITHUB_STEP_SUMMARY'):
        with open(os.environ['GITHUB_STEP_SUMMARY'], 'a') as summary:
            summary.write(report + '\n')


if __name__ == '__main__':
    asyncio.run(main())
