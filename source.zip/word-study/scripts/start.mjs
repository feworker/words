import {spawn,spawnSync} from 'node:child_process';
import {existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const venv=path.join(root,'.venv');
const python=process.env.TTS_PYTHON || path.join(venv,process.platform==='win32'?'Scripts/python.exe':'bin/python');
if(!existsSync(python)){
 for(const args of [['-m','venv',venv]]){const p=spawnSync(process.platform==='win32'?'python':'python3',args,{cwd:root,stdio:'inherit'});if(p.status!==0)process.exit(1);}
 const install=spawnSync(python,['-m','pip','install','-r','server/requirements.txt'],{cwd:root,stdio:'inherit'});if(install.status!==0)process.exit(1);
}
const backend=spawn(python,['server/tts.py'],{cwd:root,stdio:'inherit',env:process.env});
const frontend=spawn(process.platform==='win32'?'npm.cmd':'npm',['run','dev'],{cwd:root,stdio:'inherit'});
const stop=()=>{backend.kill();frontend.kill();};process.on('SIGINT',stop);process.on('SIGTERM',stop);
backend.on('exit',code=>{frontend.kill();process.exitCode=code||0;});frontend.on('exit',code=>{backend.kill();process.exitCode=code||0;});
